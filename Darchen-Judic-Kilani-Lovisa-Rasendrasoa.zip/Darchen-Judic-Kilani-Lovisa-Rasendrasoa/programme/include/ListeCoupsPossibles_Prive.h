#ifndef __LISTES_COUPS_POSSIBLES_PRIVE__
#define __LISTES_COUPS_POSSIBLES_PRIVE__
#include "ListeCoupsPossibles.h"
#include "TAD_Coup.h"
#include "TAD_Plateau.h"
#include "FaireUnePartie.h"
#include "FaireUnePartie_Prive.h"



#endif
