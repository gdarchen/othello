var searchData=
[
  ['coup',['Coup',['../structCoup.html',1,'']]],
  ['coups',['Coups',['../structCoups.html',1,'']]]
];
