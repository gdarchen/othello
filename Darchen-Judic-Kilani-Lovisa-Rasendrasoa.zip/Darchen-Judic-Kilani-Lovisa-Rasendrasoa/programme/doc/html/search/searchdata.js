var indexSectionsWithContent =
{
  0: "acdfijlnopt",
  1: "cp",
  2: "aflot",
  3: "acfijlnp",
  4: "clp",
  5: "cd"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations"
};

